zip -r ../httpscreds.zip ./  
